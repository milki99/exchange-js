<template>
  <div class="hello">
    <div class="crypto-container" v-for="value,key in cryptos">
      <span class="left">{{ key }}</span>
      <span class="left">${{ value.USD }}</span>
      <span class="left">{{ value }}</span>
    </div>
  </div>
</template>

<script>

import axios from 'axios'

export default {
  name: 'HelloWorld',
  data: () => ({
    cryptos:[],
    errors: []
  }),

  created () {
    axios.get('https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD,DAI,EUR')
    .then(response => {
      this.cryptos = response.data
      console.log(response)
    })
    .catch(e => {
      this.errors.push(e)
    })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
